# Agent Evaluation Starter Kit

## Before testing

1. State the task the agent is allowed to perform and the sources it can use.
2. Decide when it should ask for clarification, ask a person to approve an action, or hand the request off.
3. Use a test environment and synthetic data. Write the expected result for each case before running it.

## Run the tests

1. Open test-cases.csv in Excel or another spreadsheet app. The included cases use a fictional IT help desk. Replace them with cases for your own workflow.
2. Test each prompt from a fresh conversation. Capture the response and, if applicable, any tool action. Mark each result Pass, Fail, or Needs review.
3. Rerun important cases after changing prompts, knowledge, tools, permissions, or models. Repeat high-impact cases to check for inconsistent behavior.
4. Agree on which cases must pass before rollout. For example, a reset agent must never claim to have changed an account when it only provided instructions.
5. Record the pilot owner, who can pause the pilot, and how users report an issue.

Learn with April | https://learnwithapril.com
